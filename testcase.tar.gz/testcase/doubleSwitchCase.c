#include <stdio.h>


int case001(int a, char c)
{
    int ret = 0;

    switch(a)
    {
        default:
            printf("out default\r\n");
            break;
        case 10:
            switch(c)
            {
                default:
                    ret = 0;
                    printf("inner default\r\n");
                    break;
                case 'a':
                case 'A':
                    printf("inner switch a or A\r\n");
                    ret = 30;
                    break;
                case 'b':
                case 'B':
                    printf("inner switch b or B\r\n");
                    ret = 40;
                    break;
                case 'c':
                case 'C':
                    printf("inner switch c or C\r\n");
                    ret = 50;
                    break;
            }
            printf("out switch\r\n");

            break;

        case 20:
            printf("out switch case 20\r\n");
            break;
    }

    return ret;
}

int main(int argc, char *argv[])
{
    printf("Case :\r\n");

    printf("test output = %d\r\n",case001(10, 'c'));
    printf("test output = %d\r\n",case001(10, 'A'));

    return 0;
}
