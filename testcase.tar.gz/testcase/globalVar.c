
#include <stdio.h>

static int g_case_value = 2;


int case001(int a)
{
    int ret = 0;

    switch(g_case_value) {
        default:
            printf("default branch\r\n");
            ret = -1;
            break;
        case 1:
        case 11:
            ret = g_case_value + 1;
            break;
        case 2:
        case 22:
            ret = g_case_value + 2;
            break;
        case 3:
        case 33:
            ret = g_case_value + 3;
            break;
        case 5:
        case 55:
            ret = g_case_value + 5;
            break;
    }

    return ret;
}


int main(int argc, char *argv[])
{
    printf("Case :\r\n");

    printf("test output = %d\r\n", case001(g_case_value));
    
    return 0;
}

